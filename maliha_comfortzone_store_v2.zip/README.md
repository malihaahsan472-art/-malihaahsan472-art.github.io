# Maliha ComfortZone (MCZ) Online Store

A responsive starter e-commerce website for Maliha ComfortZone.

## Included
- Responsive home page
- Product categories
- Product cards
- Category filters
- Shopping cart
- WhatsApp order button
- Cash on Delivery messaging
- Mobile-friendly navigation

## Important
1. Replace the WhatsApp number `923000000000` in `index.html` with the store's real WhatsApp number.
2. Replace sample products/prices with real products.
3. For real online payments, connect a payment provider later.
4. The site is static and can be hosted free on GitHub Pages.

## Free GitHub Pages deployment
Create a GitHub repository, upload `index.html` and `style.css`, then enable GitHub Pages from Settings > Pages. Later, connect `malihacomfortzone.pk` as a custom domain.
